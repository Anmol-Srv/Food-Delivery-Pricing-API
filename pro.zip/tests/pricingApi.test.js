// const request = require('supertest');
// const app = require('../app'); // Make sure this is the Express app itself, not the server listener

// describe('/api/pricing endpoint', () => {

//   // Test with different zones
//   test.each([
//     { zone: "central", expectedPrice: 47.2 },
//     { zone: "suburban", expectedPrice: 96.5 },
//     { zone: "rural", expectedPrice: 15.00 }
//   ])('calculates the correct price for perishable items in %s zone', async ({ zone, expectedPrice }) => {
//     const postData = {
//       zone,
//       organization_id: "7",
//       total_distance: 20.1,
//       item_type: "perishable"
//     };

//     const response = await request(app)
//       .post('/api/pricing')
//       .send(postData)
//       .expect('Content-Type', /json/)
//       .expect(200);

//     expect(response.body).toEqual({ total_price: expectedPrice });
//   });

//   // Test with invalid data
//   it('returns an error for invalid input data', async () => {
//     const postData = {
//       zone: "central",
//       organization_id: "1",
//       total_distance: -5, // Invalid distance
//       item_type: "perishable"
//     };

//     const response = await request(app)
//       .post('/api/pricing')
//       .send(postData)
//       .expect('Content-Type', /json/)
//       .expect(400); // Expecting a Bad Request error

//     // Add here your expected error structure
//     expect(response.body).toEqual({ error: "Invalid total_distance provided" });
//   });

//   // Test exactly at base distance
//   it('calculates the total price correctly at the base distance', async () => {
//     const postData = {
//       zone: "central",
//       organization_id: "1",
//       total_distance: 5, // Exactly at base distance
//       item_type: "perishable"
//     };

//     const response = await request(app)
//       .post('/api/pricing')
//       .send(postData)
//       .expect('Content-Type', /json/)
//       .expect(200);

//     expect(response.body).toEqual({
//       total_price: 10 // Assuming the base price applies up to and including 5 km
//     });
//   });

//   // Test just over the base distance
//   it('calculates the total price correctly just over the base distance', async () => {
//     const postData = {
//       zone: "central",
//       organization_id: "1",
//       total_distance: 5.1, // Just over base distance
//       item_type: "perishable"
//     };

//     const response = await request(app)
//       .post('/api/pricing')
//       .send(postData)
//       .expect('Content-Type', /json/)
//       .expect(200);

//     expect(response.body).toEqual({
//       total_price: 10.75 // Assuming 0.5 extra for the additional 0.1 km
//     });
//   });
// });

const request = require('supertest');
const app = require('../app');

describe('/api/pricing endpoint', () => {
  // Test across different zones with more realistic distances
  test.each([
    { zone: "central", distance: 20.1, organization_id: "7", item_type: "perishable", expectedPrice: 47.2 },
    { zone: "suburban", distance: 30.5, organization_id: "7", item_type: "non-perishable", expectedPrice: 65.5 },
    { zone: "rural", distance: 20.1, organization_id: "4", item_type: "perishable", expectedPrice: 52.4 },
    // Add more variations based on your CSV data
  ])('calculates the correct price for $item_type items in $zone zone over $distance km', async ({ zone, distance, organization_id, item_type, expectedPrice }) => {
    const postData = { zone, organization_id, total_distance: distance, item_type };
    const response = await request(app).post('/api/pricing').send(postData).expect('Content-Type', /json/).expect(200);
    expect(response.body).toEqual({ total_price: expectedPrice });
  });

  // Test for invalid organization_id
  it('returns an error for an invalid organization ID', async () => {
    const postData = { zone: "central", organization_id: "999", total_distance: 10, item_type: "perishable" };
    const response = await request(app).post('/api/pricing').send(postData).expect('Content-Type', /json/).expect(404); // Assuming a 404 for not found
    expect(response.body).toEqual({ error: "Organization not found" });
  });

  // Test for unsupported item type
  it('returns an error for an unsupported item type', async () => {
    const postData = { zone: "central", organization_id: "1", total_distance: 10, item_type: "unknown" };
    const response = await request(app).post('/api/pricing').send(postData).expect('Content-Type', /json/).expect(400); // Assuming a 400 for bad request
    expect(response.body).toEqual({ error: "Unsupported item type" });
  });

  // More tests here based on additional rules or data variations
});
