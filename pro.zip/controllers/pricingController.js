// import { calculateDeliveryCost } from '../services/pricingService.js';

//   export const getPricing = async (req, res) => {
//   try {
//     const {
//       zone, organization_id, total_distance, item_type,
//     } = req.body;
//     const result = await calculateDeliveryCost({
//       zone, organization_id, total_distance, item_type,
//     });
//     res.json(result);
//   } catch (error) {
//     res.status(500).send(error.message);
//   }
// };
const { calculateDeliveryCost } = require('../services/pricingService');

const getPricing = async (req, res) => {
  try {
    const {
      zone,
      organization_id, // assuming that 'organization_id' in req.body can be camelCased
      total_distance, // assuming that 'total_distance' in req.body can be camelCased
      item_type, // assuming that 'item_type' in req.body can be camelCased
    } = req.body;

    const result = await calculateDeliveryCost({
      zone,
      organization_id,
      total_distance,
      item_type,
    });

    res.json(result);
  } catch (error) {
    res.status(500).send(error.message);
  }
};

module.exports = { getPricing };
